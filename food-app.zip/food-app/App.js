import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import MainStackNav from './Pages/StackNavs/StackNav';

export default class App extends React.Component {
  render() {
    return  <MainStackNav />
  }
}