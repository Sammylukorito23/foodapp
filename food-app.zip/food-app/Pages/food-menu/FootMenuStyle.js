import { StyleSheet } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
    CartNotification:{
            position: 'absolute',
            top: 0,
            right: 5,
            width: 20,
            height: 20,
            backgroundColor: '#ff0000',
            color: '#fff',
            borderRadius: 100,
            textAlign:'center',
            fontSize: 10,
            lineHeight: 20,
        },
    FoodMenuPageContainer: {
        flex: 1,
        backgroundColor: '#fff',
        padding: responsiveHeight(2.1),
        paddingTop: 0,
    },
    FoodMenuCardSet: {
        width: '100%',
        height: responsiveHeight(23),
        marginTop: responsiveHeight(2.1),
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: responsiveHeight(4), 
        overflow: 'visible',
        flex: 1,
    },
    FoodName: {
        fontSize: responsiveFontSize(2.9), 
        color: '#fff',
        lineHeight: 40,
    },
    FoodDesc: {
        fontSize: responsiveFontSize(1.7), 
        color: '#fff',
        lineHeight: 20,
        fontWeight: '100',
    },
    FoodMenuCardImgContainer: {
        flexDirection: 'row',
        width: responsiveWidth(40),
        height: responsiveHeight(15),
        alignSelf: 'center',
        position: 'absolute',
        left: 0,
        bottom: 15,
        zIndex: 10,
    },
    FoodMenuCardImg: {
        resizeMode: 'contain',
        flex: 1,
        height: 'auto',
    }

})