import { StyleSheet,Dimensions } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
const {height, width} = Dimensions.get("window");
export default StyleSheet.create({ 
    
    FoodTypeListContainer: {
        flex: 1,
        width: '100%',
        backgroundColor: '#fff',
    },
    FoodTypeListHeaderAni: {
        position: "absolute",
        height: responsiveHeight(28),
        width: width, 
        top: 0,
        justifyContent: "flex-end",
        flexDirection: "column",
        alignItems:'center',   
    },

    FoodTypeListHeaderImg: {
        bottom: responsiveHeight(2.2),
        width: responsiveWidth(36), 
        height:  responsiveHeight(24),
       
    },
    FootTypeList: {
    	backgroundColor: '#fff',
    	borderBottomColor: '#ddd',
        borderBottomWidth: 1, 
        flex: 1,
    },
    FootTypeListInner:{
    	flexDirection: 'row', 
    	flex: 1,
    	height: responsiveHeight(15),
        paddingTop:  responsiveHeight(1.4), 
        paddingBottom: responsiveHeight(1.4),
    },
    FootTypeListLeftImgContainer:{
    	height: responsiveHeight(13.5),
    	width: responsiveWidth(24),
    	flexDirection: 'row',
    	alignSelf: 'center',

    },
    FootTypeListLeftImg:{
    	flex: 1,
    	resizeMode: 'contain',
        height: 'auto', 
    },
    FootTypeListCenterContainer:{
    	flex: 1,  
    	flexDirection: 'column',
    },
    FootTypeListCenterTitle:{
    	marginBottom: 2,
    	fontSize: responsiveFontSize(2), 
    	color: '#101010', 
    	alignItems: 'flex-start',
    },
    FootTypeListCenterTitleDesc:{ 
    	 alignItems: 'flex-start', 
    	color: '#6e6e6e',
    	fontSize: responsiveFontSize(1.7),
    	fontStyle: 'italic', 

    },
    FootTypeListPriceContainer:{
    	flex: 1,
    	flexDirection: 'row',
    	paddingRight: 20,
    	alignItems:  'flex-end' ,
    },

    FootTypeListPriceText:{
    	flex: 1, 
    	fontSize: responsiveFontSize(2),
    	color: '#ff0000', 
    	justifyContent: 'flex-start',
    	fontWeight: 'bold',

    },
    FootTypeListFavoriteText:{
    	flex: 1, 
    	justifyContent: 'flex-end',
    	textAlign: 'right',
    	alignItems:'center',
    }
})