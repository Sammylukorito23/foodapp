import React, { Component } from "react";
import { Animated, View, ListView, ScrollView, Text, Dimensions,Image } from "react-native";
import Icon from 'react-native-vector-icons/Ionicons';
import Swiper from 'react-native-swiper';
import * as Animatable from 'react-native-animatable';
 
import style from './FoodTypeStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import Swipeout from 'react-native-swipeout';


const {height, width} = Dimensions.get("window");
var swipeoutBtns = [
    {
        text: 'Add',
        backgroundColor: '#3a7705',
        underlayColor: '#75d125',
    }
]; 
 var swipeoutBtnRight = [
    {
        text: 'Remove',
        backgroundColor: '#ff0000',
    }
    ]

export default class ScrollSwagger extends Component {
 static navigationOptions = {
        headerStyle: {
            backgroundColor: '#a88d75',
            zIndex: 100,
             elevation: 0,
            shadowOpacity: 0,
            shadowColor: 'transparent', 
            
        },
        headerTitle: 'COFFEE',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',
        },
        headerLeft: '',
        headerRight: (<View/>), 
    };




    constructor(props) {
        super(props);
        const ds = new ListView.DataSource({
            rowHasChanged: (r1, r2) => r1 !== r2
        });
        this.state = {
            scrollY: new Animated.Value(0),

            dataSource: ds.cloneWithRows([
                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY" delay={0} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-3.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $21 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ccc" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  754</Text> 
                        </Text> 
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>, 

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY"  delay={200} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-1.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $17 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ff0000" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  679</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY"  delay={400} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-2.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $10 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ccc" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  234</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY"  delay={600} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-4.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $34 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ccc" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  856</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY" delay={800} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-5.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $23 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ff0000" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  564</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY" delay={1000} easing="linear"  style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-3.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $14 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ccc" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  345</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                <Swipeout style={style.FootTypeList} left={swipeoutBtns} right={swipeoutBtnRight} >
                  <Animatable.View animation="flipInY" delay={1200} easing="linear" style={style.FootTypeListInner}>
                    <View style={style.FootTypeListLeftImgContainer}>
                        <Image style={style.FootTypeListLeftImg} source={require('../../images/ca-i-2.png')} /> 
                    </View>
                    <View style={style.FootTypeListCenterContainer}>
                      <Text style={style.FootTypeListCenterTitle}> Chocolate Muffin </Text>
                      <Text style={style.FootTypeListCenterTitleDesc}> Chocolate Cake </Text>
                      <View style={style.FootTypeListPriceContainer}>
                        <Text style={style.FootTypeListPriceText}> $45 </Text>
                        <Text style={style.FootTypeListFavoriteText}>
                        <Icon name="ios-heart" color="#ff0000" size={responsiveFontSize(2.2)} />  
                        <Text style={{fontSize:responsiveFontSize(1.6),marginLeft:5,color: '#6e6e6e',}}>  896</Text> 
                        </Text>  
                      </View>
                    </View>
                  </Animatable.View>
                </Swipeout>,

                
            ])
        };
    }
    renderRow(rowData) {
        console.log(rowData);
        return (
            <View style={style.FoodTypeListContainer}>
        {rowData}
      </View>
        );
    }
    render() {
         var headMov = this.state.scrollY.interpolate({
      inputRange: [0, 150, 151],
      outputRange: [0, -230, -230]
    });
    var hamovY = this.state.scrollY.interpolate({
      inputRange: [0, 150, 151],
      outputRange: [0, 0, 0]
    });
    var hamovX = this.state.scrollY.interpolate({
      inputRange: [0, 150, 151],
      outputRange: [0, 0, 0]
    });
    var imgOp = this.state.scrollY.interpolate({
      inputRange: [0, 150, 151],
      outputRange: [1, 0, 0]
    });
    var misMovY = this.state.scrollY.interpolate({
      inputRange: [0, 150, 151],
      outputRange: [0, 0, 0]
    });
    var headColor = this.state.scrollY.interpolate({
      inputRange: [0, 150],
      outputRange: ["#a88d75", "#ffcea6"]
    });
        return (
            <View style={{
                flex: 1,
                backgroundColor: '#fff',
            }}>
        <ListView
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
            renderScrollComponent={this.renderScroll.bind(this)}
            />
        <Animated.View style={[style.FoodTypeListHeaderAni, {transform: [{translateY: headMov}], backgroundColor: headColor,}]}>

          <Animated.Image source={require('../../images/ca-i-3.png')} style={[style.FoodTypeListHeaderImg, {opacity: imgOp}]} />
        </Animated.View>
      </View>
        );
    }
    _handleScroll(e) {
        // console.log(e.nativeEvent.contentOffset.y, "jvjhvhm");
    }

    renderScroll(props) {
        return (
            <Animated.ScrollView
            scrollEventThrottle={56}
            contentContainerStyle={{
                paddingTop: responsiveHeight(28)
            }}
            // Declarative API for animations ->
            onScroll={Animated.event(
                [
                    {
                        nativeEvent: {
                            contentOffset: {
                                y: this.state.scrollY
                            }
                        }
                    }
                ],
                {
                    listener: this._handleScroll.bind(this)
                },
                {
                    useNativeDriver: true // <- Native Driver used for animated events
                }
            )}
            />
        );
    }
}