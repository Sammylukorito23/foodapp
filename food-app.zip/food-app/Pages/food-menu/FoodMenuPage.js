import React from 'react';
import { StyleSheet, Text, View, ScrollView, Image, AppRegistry,TouchableHighlight,TouchableOpacity } from 'react-native';
import { createStackNavigator, } from 'react-navigation';
import Icon from 'react-native-vector-icons/Ionicons';
import Swiper from 'react-native-swiper'; 
import * as Animatable from 'react-native-animatable';
import style from './FootMenuStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';


export default class FoodMenuScreen extends React.Component {
    static navigationOptions = {
        headerStyle: {
            backgroundColor: '#fff',
            zIndex: 100,
             elevation: 0,
            shadowOpacity: 0,
            shadowColor: 'transparent', 
        },
        headerTitle: 'MENU',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',
        },
        headerLeft: <Icon name="ios-menu-outline" size={responsiveFontSize(4)} color="#000" style={{marginLeft: 15}}  />,
        headerRight:   <View style={{position: 'relative'}}>
        <Icon name="ios-cart-outline" size={responsiveFontSize(4)} color="#000" style={{marginRight: 15}}  />
        <Text style={style.CartNotification}>7</Text></View>, 
    };
    render() {
        const {navigate} = this.props.navigation;
        return (
          <ScrollView style={{flex: 1,backgroundColor: '#fff',}}> 
            <View style={style.FoodMenuPageContainer}>
            <TouchableOpacity onPress={() => this.props.navigation.navigate('FoodItemScreen')}>
            <Animatable.View animation="bounceIn"  delay={0} easing="linear" style={[style.FoodMenuCardSet, {backgroundColor: '#a88d75',marginTop:0}]}> 
                <Text style={style.FoodName}>Coffee</Text>
                <Text style={style.FoodDesc}>Lattes, Cappuccino, Choc Mocha</Text>
                <View style={style.FoodMenuCardImgContainer}>
                    <Image style={style.FoodMenuCardImg} source={require('../../images/ca-i-3.png')} />
                </View>
              </Animatable.View>
            </TouchableOpacity> 

              <Animatable.View animation="bounceIn"  delay={200} easing="linear" style={[style.FoodMenuCardSet, {backgroundColor: '#3a7705',}]}>
                <Text style={style.FoodName}>Breakfast</Text>
                <Text style={style.FoodDesc}>Hearty, hot and full of flavor</Text>
                <View style={style.FoodMenuCardImgContainer}>
                    <Image style={style.FoodMenuCardImg} source={require('../../images/h-d-4.png')} />
                </View>
              </Animatable.View>
              
              <Animatable.View animation="bounceIn"  delay={400} easing="linear" style={[style.FoodMenuCardSet, {backgroundColor: '#e22d3d',}]}> 
                <Text style={style.FoodName}>Lunch</Text>
                <Text style={style.FoodDesc}>Simple, delicious, heigh-quality </Text>
                <View style={style.FoodMenuCardImgContainer}>
                    <Image style={style.FoodMenuCardImg} source={require('../../images/ca-i-6.png')} />
                </View>
              </Animatable.View>
              <Animatable.View animation="bounceIn"  delay={600} easing="linear" style={[style.FoodMenuCardSet, {backgroundColor: '#420d0b',}]}> 
                <Text style={style.FoodName}>Desserts</Text>
                <Text style={style.FoodDesc}>Prefectly backed, warm goodies</Text>
                <View style={style.FoodMenuCardImgContainer}>
                    <Image style={style.FoodMenuCardImg} source={require('../../images/ca-i-7.png')} />
                </View>
              </Animatable.View>
            </View>
          </ScrollView>
        );
    }

}

