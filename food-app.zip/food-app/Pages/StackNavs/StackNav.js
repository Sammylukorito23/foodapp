import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import * as Animatable from 'react-native-animatable';
import { StyleSheet, Text, View,ScrollView,SafeAreaView,Image,TouchableHighlight, TouchableOpacity } from 'react-native';
import { createStackNavigator, createDrawerNavigator,DrawerItems } from 'react-navigation';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';

import HomeScreen from '../HomePage/HomePage';
import HotelScreen from '../HotelsPage/HotelPage';
import FoodMenuScreen from '../food-menu/FoodMenuPage';
import FoodItemScreen from '../food-menu/FoodTypePage';
import FavoriteScreen from '../favorites/favoritePage';
import OrderScreen from '../OrderPage/OrderPage'; 
import CheckOutScreen from '../CheckOutPage/CheckOutPage'; 
import MotionPage from '../Motion_Ani/Motion_page';
import SideMenu from '../SideMenu/SideMenu'; 

export const StackNav = createStackNavigator({ 
    HomeScreen: { screen: HomeScreen },
    HotelScreen: { screen: HotelScreen },
    FoodMenuScreen: { screen: FoodMenuScreen },
    FoodItemScreen: { screen: FoodItemScreen },
    FavoriteScreen: { screen: FavoriteScreen },
    OrderScreen: { screen: OrderScreen },
    CheckOutScreen: { screen: CheckOutScreen },
    MotionPage: { screen: MotionPage }, 
    
});

export const Drawer = createDrawerNavigator({
    HomeScreen : {screen: StackNav},
    HotelScreen: { screen: StackNav },
    FoodMenuScreen: { screen: StackNav },
    FavoriteScreen: { screen: StackNav },
    MotionPage: { screen: StackNav },
},
 {
  contentComponent: SideMenu,
  drawerWidth: responsiveWidth(82)
} 
); 


export default Drawer; 