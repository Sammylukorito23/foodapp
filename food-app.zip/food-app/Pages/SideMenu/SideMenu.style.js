import { StyleSheet, Dimensions } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
    container: {
        flex: 1
    },
    SideMenuContainer: {
        position: 'absolute',
        zIndex: 10,
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 0, 0, 0.57)',
        padding: responsiveHeight(1.3),
        paddingTop: responsiveHeight(3.2),
    },
    MenuBGImg: {
        width: '100%',
        height: '110%',
        resizeMode: 'cover',

    },
    sidebarProfile: {
        height: responsiveHeight(20),
        alignItems: 'center',
        padding: responsiveHeight(2),
        position: 'relative',
        zIndex: 10,
        paddingBottom: responsiveHeight(7),
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
    },
    sidebarText: {
        color: '#fff',
        fontSize: responsiveFontSize(1.9),
        fontWeight: '500',
    },

    sidebarTextSmall: {
        color: '#fff',
        fontSize: responsiveFontSize(1.5),
        fontWeight: '300',
        marginBottom: 7,
    },

    LandingImg: {
        flex: 1,
        width: responsiveWidth(18),
        height: responsiveHeight(10),
        borderRadius: responsiveHeight(20),
    },
    footerContainer: {
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        width: '100%',
        height: responsiveHeight(7),
        paddingTop: responsiveHeight(1.8),
        paddingLeft: responsiveHeight(2),
        position: 'absolute',
        bottom: 0,
    },
    SideMenuSetContainer: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        marginTop: responsiveHeight(2),
        paddingBottom: responsiveHeight(11),
    },
    SideMenuSets: {
        width: "48.4%",
        marginBottom: responsiveHeight(1.3),
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        height: responsiveHeight(20),
        padding: responsiveHeight(1.4),
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',

    },
    MenuIcon: {
        textAlign: 'center',
        color: '#fff',
        fontSize: responsiveFontSize(5),
        marginBottom: 5,
    },
    MenuText: {
        textAlign: 'center',
        color: '#fff',
        fontSize: responsiveFontSize(2),
    }
})