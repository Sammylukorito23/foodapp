import PropTypes from 'prop-types';
import React, { Component } from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import { Animated, View, ListView, Alert, ScrollView, Text, Dimensions, Image, TouchableOpacity } from "react-native";
import style from './SideMenu.style';
import { NavigationActions } from 'react-navigation';

class SideMenu extends Component {
    navigateToScreen = (route) => () => {
        const navigateAction = NavigationActions.navigate({
            routeName: route
        });
        this.props.navigation.dispatch(navigateAction);
    }

    render() {
        return (
            <View style={style.container}>
      <Image style={style.MenuBGImg} source={require('../../images/menu-bg.jpg')} /> 
        <ScrollView style={style.SideMenuContainer}>
        
        <View style={style.sidebarProfile}>
            <View style={{
                position: 'relative',
                height: responsiveHeight(23),
                paddingBottom: responsiveHeight(6),
                flexDirection: 'row',
                alignItems: 'center',
            }}>
              <View style={{
                flex: 1,
                width: responsiveWidth(18),
                height: responsiveHeight(10),
            }}>
                <Image style={style.LandingImg} source={require('../../images/user-img1.jpg')} /> 
              </View>
              <View style={{
                flex: 3,
                paddingLeft: 15
            }}> 
                <Text numberOfLines={1} style={style.sidebarText}>Larry Howard</Text>
                <Text numberOfLines={1} style={style.sidebarTextSmall}>United States</Text>
                
              </View>
            </View>
          </View>

          <View style={style.SideMenuSetContainer}>
            <TouchableOpacity style={style.SideMenuSets} onPress={this.navigateToScreen('HomeScreen')}>
            <Icon style={style.MenuIcon} name="ios-home-outline"></Icon>
            <Text style={style.MenuText}>Home Page</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.SideMenuSets} onPress={this.navigateToScreen('HotelScreen')}>
            <Icon style={style.MenuIcon} name="ios-home-outline"></Icon>
            <Text style={style.MenuText}>Hotels</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.SideMenuSets} onPress={this.navigateToScreen('FoodMenuScreen')}>
            <Icon style={style.MenuIcon} name="ios-pizza-outline"></Icon>
            <Text style={style.MenuText}>Food Menu</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.SideMenuSets} onPress={this.navigateToScreen('FavoriteScreen')}>
            <Icon style={style.MenuIcon} name="ios-heart-outline"></Icon>
            <Text style={style.MenuText}>Favorite</Text>
          </TouchableOpacity>
          <TouchableOpacity style={style.SideMenuSets} onPress={this.navigateToScreen('MotionPage')}>
            <Icon style={style.MenuIcon} name="ios-list-box-outline"></Icon>
            <Text style={style.MenuText}>My Check</Text>
          </TouchableOpacity>
          </View>

         <View style={style.footerContainer}>
          <Text style={{
                color: '#fff',
                fontSize: responsiveFontSize(2),
            }}>LOGOUT</Text>
        </View>
         

        </ScrollView>
        
      </View>
        );
    }
}

SideMenu.propTypes = {
    navigation: PropTypes.object
};

export default SideMenu;