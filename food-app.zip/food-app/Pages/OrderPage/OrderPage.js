import React, { Component } from "react";
import { Animated, View, ListView, Alert, ScrollView, Text, Dimensions, Image,TouchableOpacity,TouchableWithoutFeedback } from "react-native";
import Icon from 'react-native-vector-icons/Ionicons';
import * as Animatable from 'react-native-animatable';
import { Dropdown } from 'react-native-material-dropdown';
import style from './OrderPageStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';




export default class OrderScreen extends React.Component {
    handleViewRef = ref => this.view = ref;
    bounceIn = () => this.view.bounceIn(800).then(endState => console.log(endState.finished ? 'bounceIn finished' : 'bounceIn cancelled'));
    static navigationOptions = {
        headerStyle: {
            backgroundColor: '#fff',
            zIndex: 100,
             elevation: 0,
            shadowOpacity: 0,
            shadowColor: 'transparent', 
          

        },
        headerTitle: 'CHOCO COFFEE',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',

        },
        headerLeft: '',
        headerRight: (<View/>),
    };

 _showAlert = () => {
    Alert.alert(
      'Success',
      'Product added in your favorite list',
      [
        {text: 'OK'},
      ],
      { cancelable: false }
    )
  };


    render() {
        let dataQ = [{
      value: '1',
    }, {
      value: '2',
    }, {
      value: '3',
    },{
      value: '4',
    },{
      value: '5',
    },{
      value: '6',
    },{
      value: '7',
    },{
      value: '8',
    },{
      value: '9',
    },{
      value: '10',
    },
    ];
    let dataS = [{
      value: 'S',
    },
    {
      value: 'M',
    },
    {
      value: 'XL',
    },
    {
      value: 'XXL',
    },
    ];


        return (
            <ScrollView style={{flex: 1,backgroundColor: '#fff'}}> 
              <View style={style.OrderPageContainer}>
                <View style={style.OrderTopHeader}>
                        <Animatable.View animation="pulse" easing="ease-out" iterationCount="infinite" duration={500} style={style.OrderTopHeaderLeft}>
                           <Icon name="ios-heart" size={responsiveFontSize(3)} color="#ff0000" style={{lineHeight: responsiveHeight(3.1),}}  />
                        </Animatable.View>
                        <View style={style.OrderTopHeaderRight}>
                            <Text style={style.OrderTopHeaderPrice}>$ 17.59</Text>
                        </View>
                   </View>
                   <Animatable.View style={style.OrderBodyImgContainer} delay={100} animation="bounceIn" easing="linear" duration={1500} >
                     <Image style={style.OrderBodyImg} source={require('../../images/ca-i-3.png')} />
                   </Animatable.View>
                   <View style={style.OrderFooterBody}>
                     <Text style={style.OrderFooterBodyText}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore Lorem ipsum dolor sit amet, consectetur</Text>
                   </View>
                   <View style={style.ItemQuantitySizeContainer}>
                     <View style={[style.ItemQuantitySizeContainerSet,{borderRightWidth:1,borderRightColor: '#ccc'}]}>
                       <Dropdown containerStyle={{width: responsiveWidth(25),}} inputContainerStyle={{ borderBottomColor: 'transparent' }} fontSize={responsiveFontSize(2)} labelFontSize={responsiveFontSize(1.5)} label='Quantity'data={dataQ}/>
                    </View>
                    <View style={style.ItemQuantitySizeContainerSet}>
                       <Dropdown containerStyle={{width: responsiveWidth(25),}} inputContainerStyle={{ borderBottomColor: 'transparent' }} fontSize={responsiveFontSize(2)} labelFontSize={responsiveFontSize(1.5)} label='Size' data={dataS}/>
                    </View> 
                   </View>
                   <Animatable.View style={style.OrderFullWidthButtonContainer}  delay={100} animation="bounceIn" easing="linear" duration={1500} >
                        <TouchableOpacity style={style.OrderFullWidthButton} onPress={() => this.props.navigation.navigate('CheckOutScreen')}>  
                           <Text style={style.OrderFullWidthButtonText}>{'Order Now'.toUpperCase()}</Text>  
                        </TouchableOpacity> 
                    </Animatable.View>
                    
                     <Animatable.View style={style.OrderFullWidthButtonContainer}  delay={200} animation="bounceIn" easing="linear" duration={1500}>
                        <TouchableOpacity style={[style.OrderFullWidthButton,{backgroundColor: 'transparent',borderWidth: 1,borderColor: '#ccc'}]}  onPress={this._showAlert}>  
                            <Text style={[style.OrderFullWidthButtonText,{color: '#696969'}]}>{'Add to favorites'.toUpperCase()}</Text>  
                        </TouchableOpacity> 
                    </Animatable.View>
              </View>
            </ScrollView>
        );
    }
}




