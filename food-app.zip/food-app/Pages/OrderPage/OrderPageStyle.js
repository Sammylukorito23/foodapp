import { StyleSheet, Dimensions } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
    OrderPageContainer: {
        flex: 1,
        padding: responsiveHeight(2.1),
    },
    OrderTopHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: responsiveWidth(5),
        marginTop: responsiveWidth(1),
    },
    OrderTopHeaderLeft: {
        alignItems: 'flex-start',
    },
    OrderTopHeaderRight: {
        alignItems: 'flex-end',
    },
    OrderTopHeaderPrice: {
        color: '#ff0000',
        fontSize: responsiveFontSize(2),
        lineHeight: responsiveHeight(3),
    },
    OrderBodyImgContainer: {
        flexDirection: 'row',
        width: responsiveWidth(130),
        height: responsiveHeight(25),
        alignSelf: 'center',
    },
    OrderBodyImg: {
        resizeMode: 'contain',
        flex: 1,
        height: 'auto',
    },
    OrderFooterBody: {
        alignSelf: 'center',
        padding: responsiveHeight(3.2),
    },
    OrderFooterBodyText: {
        flexDirection: 'row',
        color: '#696969',
        fontSize: responsiveFontSize(1.7),
        textAlign: 'center',
        lineHeight: responsiveHeight(3),
    },
    ItemQuantitySizeContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: responsiveHeight(3),
        marginTop: responsiveHeight(2),
    },
    ItemQuantitySizeContainerSet: {
        flex: 1,
        width: responsiveWidth(15),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    ProductDropdown: {
        flex: 1,
    },
    OrderFullWidthButtonContainer: {
        alignItems: 'center',
    },
    OrderFullWidthButton: {
        width: '100%',
        backgroundColor: '#ff0000',
        height: responsiveHeight(6.9),
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: responsiveHeight(3),
    },
    OrderFullWidthButtonText: {
        fontSize: responsiveFontSize(1.7),
        color: 'white',
    },
})