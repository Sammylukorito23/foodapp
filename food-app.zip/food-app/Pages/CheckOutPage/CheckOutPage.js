import React, { Component } from "react";
import { Animated, View, ListView, Alert, ScrollView, Text, Dimensions, Image,TouchableOpacity } from "react-native";
import Icon from 'react-native-vector-icons/Ionicons';
import * as Animatable from 'react-native-animatable';
import style from './CheckOutStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';




export default class CheckOutScreen extends React.Component {
static navigationOptions = {
        headerStyle: {
            zIndex: 1000,
            shadowOpacity: 0,
            backgroundColor: 'transparent',
        position: 'absolute',
        height: 50,
        top: 0,
        left: 0,
        right: 0,
        width: '100%', 
        }, 
        headerTitle: 'Order Summary',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',
            color: '#fff',
             zIndex: 1000,

        },
        headerLeft: '',
        headerTintColor: 'white',
        headerRight: (<View/>),
    };

	render() {
		return (
			<ScrollView style={{flex: 1,backgroundColor: '#fff',zIndex: 10,}}>
				<View style={style.CheckOutPageContainer}>
					<View style={style.CheckOutPageHeaderContainer}>
						<View style={style.CheckOutPageHeaderContainerOverlay}></View>
						<Image style={style.CheckOutPageHeaderContainerImg} source={require('../../images/b-i-3.jpg')} />
					</View>
					<View style={style.CheckOutPageInnerContainer}>
						<Text style={style.CheckOutProductTitle}>Greek Salat</Text>
						<View style={style.CheckOutPageTableSet}>
							<Text style={style.CheckOutPageTableSetLeft}>Base Price</Text>
							<Text style={style.CheckOutPageTableSetRight}>$32.00</Text>
					    </View>
					    <View style={style.CheckOutPageTableSet}>
							<Text style={style.CheckOutPageTableSetLeft}>Quantity</Text>
							<Text style={style.CheckOutPageTableSetRight}>2</Text>
					    </View>
					    <View style={[style.CheckOutPageTableSet,{borderBottomColor: 'transparent',marginBottom:responsiveHeight(13)}]}>
							<Text style={style.CheckOutPageTableSetLeft}>Size</Text>
							<Text style={style.CheckOutPageTableSetRight}>Small</Text>
					    </View>
					    <View style={[style.CheckOutPageTableSet,{borderBottomColor: 'transparent',borderTopColor:'#ccc',borderTopWidth:1}]}>
							<Text style={[style.CheckOutPageTableSetLeft,{fontWeight: 'bold',color:'#101010',fontSize: responsiveFontSize(1.8),}]}>Total:</Text>
							<Text style={[style.CheckOutPageTableSetRight,{fontWeight: 'bold',color:'#ff0000',}]}>$64.00</Text>
					    </View>

					    <Animatable.View style={style.OrderFullWidthButtonContainer}  delay={100} animation="bounceIn" easing="linear" duration={1500} >
                        <TouchableOpacity style={style.OrderFullWidthButton} onPress={() => this.props.navigation.navigate('')}>  
                           <Text style={style.OrderFullWidthButtonText}>{'Confirm the order'.toUpperCase()}</Text>  
                        </TouchableOpacity> 
                    </Animatable.View>
                    
                     <Animatable.View style={style.OrderFullWidthButtonContainer}  delay={200} animation="bounceIn" easing="linear" duration={1500}>
                        <TouchableOpacity style={[style.OrderFullWidthButton,{backgroundColor: 'transparent',borderWidth: 1,borderColor: '#ccc'}]}>  
                            <Text style={[style.OrderFullWidthButtonText,{color: '#696969'}]}>{'Cancle the order'.toUpperCase()}</Text>  
                        </TouchableOpacity> 
                    </Animatable.View>
					</View>
				</View>
			</ScrollView>
        );
    }
}