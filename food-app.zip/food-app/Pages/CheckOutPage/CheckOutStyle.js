import { StyleSheet, Dimensions } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
    CheckOutPageContainer: {
        flex: 1,
    },
    CheckOutPageHeaderContainer: {
        height: responsiveFontSize(32.7),
        alignSelf: 'center',
        width: '100%',
        flex: 1,
        marginTop: -50,

    },
    CheckOutPageHeaderContainerImg: {
        resizeMode: 'contain',
        width: '100%',
        height: responsiveFontSize(32.7),
        flex: 1,
    },
    CheckOutPageHeaderContainerOverlay: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.51)',
        zIndex: 1
    },
    CheckOutPageInnerContainer: {
        flex: 1,
        padding: responsiveHeight(2.1),
    },
    CheckOutProductTitle: {
        flex: 1,
        fontSize: responsiveFontSize(2.1),
        color: '#101010',
        marginBottom: responsiveHeight(1),
        marginTop: responsiveHeight(1),
    },
    CheckOutPageTableSet: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        height: responsiveHeight(8),
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        flexDirection: 'row',

    },
    CheckOutPageTableSetLeft: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: responsiveFontSize(1.6),
        color: '#6e6e6e'
    },
    CheckOutPageTableSetRight: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: responsiveFontSize(1.8),
        color: '#101010',
        textAlign: 'right',
    },
    OrderFullWidthButtonContainer: {
        alignItems: 'center',
    },
    OrderFullWidthButton: {
        width: '100%',
        backgroundColor: '#ff0000',
        height: responsiveHeight(6.9),
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: responsiveHeight(3),
    },
    OrderFullWidthButtonText: {
        fontSize: responsiveFontSize(1.7),
        color: 'white',
    }, 
})