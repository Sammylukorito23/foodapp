import React from 'react';
import { StyleSheet, Text, View, ScrollView, Image, AppRegistry, TouchableHighlight, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import * as Animatable from 'react-native-animatable';
import style from './favoriteStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';


export default class FavoriteScreen extends React.Component {
    static navigationOptions = {
        headerStyle: {
            backgroundColor: '#e8e8e8',
            zIndex: 100,
            elevation: 0,
            shadowOpacity: 0,
            shadowColor: 'transparent',
        },
        headerTitle: 'FAVORITE',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',
        },
        headerLeft: <Icon name="ios-menu-outline" size={responsiveFontSize(4)} color="#000" style={{
            marginLeft: 15
        }}  />,
        headerRight: <View style={{position: 'relative'}}>
        <Icon name="ios-cart-outline" size={responsiveFontSize(4)} color="#000" style={{marginRight: 15}}  />
        <Text style={style.CartNotification}>7</Text></View>,
    };
    render() {

        return (
            <ScrollView style={{
                flex: 1,
                backgroundColor: '#e8e8e8',
            }}> 
            <View style={style.FavoritPageContainer}>
                <View style={style.FavoritProductListContainer}>
                    <Animatable.View animation="fadeInLeft" duration={600}  delay={0} easing="linear" style={style.FavoritProductListSet}>
                       <TouchableOpacity style={{flex:1}}  onPress={() => this.props.navigation.navigate('OrderScreen')}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={style.FavoritProductListMainTitle}> Dark Roast</Text>
                            <Text style={style.FavoritProductListsubTitle}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-3.png')} /> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>
                            <Text style={style.FavoritProductListSetPrice}>$10.50</Text>
                            <Icon name="md-remove-circle" style={style.FavoritProductListSetRemove} />
                        </View>
                        </TouchableOpacity>
                    </Animatable.View>  

                    <Animatable.View animation="fadeInRight" duration={600}  delay={200} easing="linear" style={[style.FavoritProductListSet, {backgroundColor: '#ff0000',}]}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={[style.FavoritProductListMainTitle,{color:'#fff'}]}> Dark Roast</Text>
                            <Text style={[style.FavoritProductListsubTitle,{color:'#fff'}]}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-1.png')} /> 
                        </View>
                        <View style={[style.FavoritProductListSetPriceContainer,{marginTop:-50}]}>
                           <Text style={[style.FavoritProductListSetPrice,{color:'#fff'}]}>SALE</Text> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>

                            <Text style={[style.FavoritProductListSetPrice,{color:'#fff'}]}>$10.50</Text>
                            <Icon name="md-remove-circle" style={[style.FavoritProductListSetRemove,{color:'#fff'}]} />
                        </View>
                    </Animatable.View> 

                    <Animatable.View animation="fadeInLeft" duration={600}  delay={400} easing="linear" style={style.FavoritProductListSet}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={style.FavoritProductListMainTitle}> Dark Roast</Text>
                            <Text style={style.FavoritProductListsubTitle}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-2.png')} /> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>
                            <Text style={style.FavoritProductListSetPrice}>$10.50</Text>
                            <Icon name="md-remove-circle" style={style.FavoritProductListSetRemove} />
                        </View>
                    </Animatable.View> 

                    <Animatable.View animation="fadeInRight" duration={600}  delay={600} easing="linear" style={style.FavoritProductListSet}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={style.FavoritProductListMainTitle}> Dark Roast</Text>
                            <Text style={style.FavoritProductListsubTitle}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-5.png')} /> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>
                            <Text style={style.FavoritProductListSetPrice}>$10.50</Text>
                            <Icon name="md-remove-circle" style={style.FavoritProductListSetRemove} />
                        </View>
                    </Animatable.View> 

                     <Animatable.View animation="fadeInLeft" duration={600}  delay={800} easing="linear" style={[style.FavoritProductListSet, {backgroundColor: '#ff0000',}]}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={[style.FavoritProductListMainTitle,{color:'#fff'}]}> Dark Roast</Text>
                            <Text style={[style.FavoritProductListsubTitle,{color:'#fff'}]}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-4.png')} /> 
                        </View>
                        <View style={[style.FavoritProductListSetPriceContainer,{marginTop:-50}]}>
                           <Text style={[style.FavoritProductListSetPrice,{color:'#fff'}]}>SALE</Text> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>

                            <Text style={[style.FavoritProductListSetPrice,{color:'#fff'}]}>$10.50</Text>
                            <Icon name="md-remove-circle" style={[style.FavoritProductListSetRemove,{color:'#fff'}]} />
                        </View>
                    </Animatable.View>  

                    <Animatable.View animation="fadeInRight" duration={600}  delay={1000} easing="linear" style={style.FavoritProductListSet}>
                        <View style={style.FavoritProductListSetTitle}>
                            <Text style={style.FavoritProductListMainTitle}> Dark Roast</Text>
                            <Text style={style.FavoritProductListsubTitle}> Dark Roast</Text>
                        </View>
                        <View style={style.FavoritProductListSetImgContainer}>
                         <Image style={style.FavoritProductListSetImg} source={require('../../images/ca-i-3.png')} /> 
                        </View>
                        <View style={style.FavoritProductListSetPriceContainer}>
                            <Text style={style.FavoritProductListSetPrice}>$10.50</Text>
                            <Icon name="md-remove-circle" style={style.FavoritProductListSetRemove} />
                        </View>
                    </Animatable.View> 

                </View>
            </View>
          </ScrollView>
        );
    }

}

