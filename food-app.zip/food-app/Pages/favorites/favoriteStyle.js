import { StyleSheet, Dimensions } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
	CartNotification:{
			position: 'absolute',
			top: 0,
			right: 5,
			width: responsiveWidth(5),
			height: responsiveHeight(3),
			backgroundColor: '#ff0000',
			color: '#fff',
			borderRadius: 100,
			textAlign:'center',
			fontSize: 10,
			lineHeight: responsiveHeight(3),
		},
    FavoritPageContainer: {
        flex: 1,
        padding: responsiveHeight(2.1),
        paddingTop: 0,
    },
    FavoritProductListContainer: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
    FavoritProductListSet: {
        width:  responsiveWidth(44.3),
        marginBottom:  responsiveHeight(2.4),
        backgroundColor: '#fff',
         height: responsiveHeight(30), 
         padding:  responsiveHeight(1.4), 
    },
    FavoritProductListSetTitle:{
    	flex: 1, 
    	marginBottom:  responsiveHeight(1.2),
    },
    FavoritProductListMainTitle:{
    	fontSize: responsiveFontSize(1.9),
    	color: '#101010',  
    },
    FavoritProductListsubTitle:{
    	fontSize:  responsiveFontSize(1.4),
    	color: '#6e6e6e', 
    	fontStyle: 'italic', 
    },
    FavoritProductListSetImgContainer:{
    	
    	width:  responsiveWidth(24), 
    	height:  responsiveHeight(25),
    	flexDirection: 'row',
    	alignSelf: 'center',
    	justifyContent: 'flex-start',
    },
    FavoritProductListSetImg:{
    	justifyContent: 'flex-start',
    	flex: 1,
    	resizeMode: 'contain',
        height: 'auto',
    },
    FavoritProductListSetPriceContainer:{
    	flex: 1,
    	flexDirection: 'row',
    	justifyContent: 'flex-end',
    	alignItems:  'flex-end' ,
    },
    FavoritProductListSetPrice:{
    	flex: 1, 
    	fontSize: responsiveFontSize(1.7),
    	color: '#ff0000', 
    	justifyContent: 'flex-start',
    },
    FavoritProductListSetRemove:{
    	fontSize:  responsiveFontSize(2.7),
    	color: '#ccc',
    }
})