import { StyleSheet } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({

    wrapper: {
        backgroundColor: '#e8e8e8',
        flex: 1,
    },
    swiperPaginationDotDefault: {
        backgroundColor: 'rgba(0,0,0,.2)',
        width: 5,
        height: 5,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3
    },
    swiperPaginationDotActive: {
        backgroundColor: '#ff0000',
        width: 8,
        height: 8,
        borderRadius: 4,
        marginLeft: 3,
        marginRight: 3,
        marginTop: 3,
        marginBottom: 3
    },
    slide1: {
        flex: 1,
        paddingLeft: responsiveWidth(10),
        paddingRight: responsiveWidth(10),
        paddingTop: responsiveWidth(5),   
    },
    HotelSlideCard: {
        width: '100%',
        height: '85%',
        backgroundColor: '#fff',
        padding: responsiveWidth(7), 
        borderRadius: 15,
        shadowOffset: { width: 10, height: 10 },
        shadowOpacity: 1,
        shadowColor: '#000',
        elevation: 9,
        overflow: 'visible',

    },
    HotelSlideCardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: responsiveWidth(7),
    },
    HotelSlideCardHeaderLeft: {
        alignItems: 'flex-start',
    },
    HotelSlideCardHeaderRight: {
        alignItems: 'flex-end',
    },
    HotDealCardPrice: {
        color: '#ff0000',
        fontSize: responsiveFontSize(3), 
        lineHeight: responsiveHeight(3.5),
    },
    HotelSlideCardBodyImgContainer: {

        flexDirection: 'row',
        width: responsiveWidth(100),
        height: responsiveHeight(25),
        alignSelf: 'center',
    },
    HotelSlideCardBodyImg: {
        resizeMode: 'contain',
        flex: 1,
        height: 'auto',
    },
    HotelSlideCardFooterContainer: {
        flexDirection: 'row',
        alignSelf: 'center',
        height: 'auto',
    },
    HotelSlideCardFooterTitle: {
        fontSize: responsiveFontSize(3),
        color: '#101010',
        marginTop: responsiveHeight(2),
    },
    HotelSlideCardFooterBody: {
        alignSelf: 'center',  
        padding: 20,
    },  
    HotelSlideCardFooterBodyText: {
        flexDirection: 'row',
        color: '#696969',
        fontSize: responsiveFontSize(1.7),
        textAlign: 'center',
        lineHeight:  responsiveHeight(3),
    },
    HotelSlideCardFooterButtonContainer:{
      flex: 1,
      alignItems:'center' ,
    },
    HomeFullWidthButton: {
     width: '80%', 
    backgroundColor: '#ff0000',
    height:responsiveHeight(6), 
    flexDirection: 'row', 
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    },
    HomeFullWidthButtonText: {
        fontSize: responsiveFontSize(2),
        color: 'white',
        textAlign: 'center', 
    },
    
})