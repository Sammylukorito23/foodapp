import React from 'react';
import { StyleSheet, Text, View, Button, Image, AppRegistry,TouchableHighlight } from 'react-native';
import { createStackNavigator, } from 'react-navigation';
import Icon from 'react-native-vector-icons/Ionicons';
import Swiper from 'react-native-swiper'; 
import style from './HotelStyle';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';


export default class HotelScreen extends React.Component {
    static navigationOptions = {
        headerStyle: {
            backgroundColor: '#e8e8e8',
            zIndex: 100,
            elevation: 0,
            shadowOpacity: 0,
            shadowColor: 'transparent',
        },
        headerTitle: 'HOT DEALS',
        headerTitleStyle: {
            flex: 1,
            textAlign: 'center',
            alignSelf: 'center',
            fontSize: responsiveFontSize(2.3),
            fontWeight: 'normal',
        },
        headerLeft: <Icon name="ios-menu-outline" size={responsiveFontSize(4)} color="#000" style={{marginLeft: 15}}  />,
        headerRight: (<View/>),
    };
    render() {
        const {navigate} = this.props.navigation;
        return (
            <Swiper style={style.wrapper} loop={false} showsButtons={false} showsPagination={true} dot={<View style={style.swiperPaginationDotDefault} />} activeDot={<View style={style.swiperPaginationDotActive} />}>
              <View style={style.slide1}> 
                <View style={style.HotelSlideCard}>
                  <View style={style.HotelSlideCardHeader}>
                        <View style={style.HotelSlideCardHeaderLeft}>
                           <Icon name="ios-heart" size={responsiveFontSize(4)} color="#ccc" style={{lineHeight: responsiveHeight(3.9),}}  />
                        </View>
                        <View style={style.HotelSlideCardHeaderRight}>
                            <Text style={style.HotDealCardPrice}>$ 17.59</Text>
                        </View>
                   </View>
                   <View style={style.HotelSlideCardBodyImgContainer}>
                     <Image style={style.HotelSlideCardBodyImg} source={require('../../images/h-d-2.png')} />
                   </View>
                   <View style={style.HotelSlideCardFooterContainer}>
                     <Text  style={style.HotelSlideCardFooterTitle}>Snack Meal Set</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterBody}>
                     <Text style={style.HotelSlideCardFooterBodyText}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterButtonContainer}>
                    <TouchableHighlight style={style.HomeFullWidthButton}  onPress={() => this.props.navigation.navigate('FoodMenuScreen')}>  
                        <Text style={style.HomeFullWidthButtonText}>{'Full Menu'.toUpperCase()}</Text>  
                    </TouchableHighlight> 
                   </View>
                </View>
              </View>

              <View style={style.slide1}>
                <View style={style.HotelSlideCard}>
                  <View style={style.HotelSlideCardHeader}>
                        <View style={style.HotelSlideCardHeaderLeft}>
                           <Icon name="ios-heart" size={responsiveFontSize(4)} color="#ff0000" style={{lineHeight: responsiveHeight(3.9),}}  />
                        </View>
                        <View style={style.HotelSlideCardHeaderRight}>
                            <Text style={style.HotDealCardPrice}>$ 40.00</Text>
                        </View>
                   </View>
                   <View style={style.HotelSlideCardBodyImgContainer}>
                     <Image style={style.HotelSlideCardBodyImg} source={require('../../images/h-d-4.png')} />
                   </View>
                   <View style={style.HotelSlideCardFooterContainer}>
                     <Text  style={style.HotelSlideCardFooterTitle}>Ricette Facili</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterBody}>
                     <Text style={style.HotelSlideCardFooterBodyText}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterButtonContainer}>
                    <TouchableHighlight style={style.HomeFullWidthButton}  onPress={() => this.props.navigation.navigate('FoodMenuScreen')}>  
                        <Text style={style.HomeFullWidthButtonText}>{'Full Menu'.toUpperCase()}</Text>  
                    </TouchableHighlight> 
                   </View>
                </View>
              </View>

              <View style={style.slide1}> 
                <View style={style.HotelSlideCard}>
                  <View style={style.HotelSlideCardHeader}>
                        <View style={style.HotelSlideCardHeaderLeft}>
                           <Icon name="ios-heart" size={responsiveFontSize(4)} color="#ccc" style={{lineHeight: responsiveHeight(3.9),}}  />
                        </View>
                        <View style={style.HotelSlideCardHeaderRight}>
                            <Text style={style.HotDealCardPrice}>$ 10.30</Text>
                        </View>
                   </View>
                   <View style={style.HotelSlideCardBodyImgContainer}>
                     <Image style={style.HotelSlideCardBodyImg} source={require('../../images/h-d-1.png')} />
                   </View>
                   <View style={style.HotelSlideCardFooterContainer}>
                     <Text  style={style.HotelSlideCardFooterTitle}>Burger Bucket</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterBody}>
                     <Text style={style.HotelSlideCardFooterBodyText}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do tempor incididunt ut labore</Text>
                   </View>
                   <View style={style.HotelSlideCardFooterButtonContainer}>
                    <TouchableHighlight style={style.HomeFullWidthButton}  onPress={() => this.props.navigation.navigate('FoodMenuScreen')}>  
                        <Text style={style.HomeFullWidthButtonText}>{'Full Menu'.toUpperCase()}</Text>  
                    </TouchableHighlight> 
                   </View>
                </View>
              </View>

          </Swiper>
        );
    }

}

AppRegistry.registerComponent('myproject', () => Swiper);