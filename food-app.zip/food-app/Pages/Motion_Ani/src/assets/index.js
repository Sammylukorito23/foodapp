export default {
  'Ice Coffee': require('./ca-i-3.png'),
  'Burger Combo': require('./h-d-2.png'),
  'cappuccino': require('./ca-i-4.png'),
  'veggie Meals': require('./h-d-4.png'),
  'Bread Omelette': require('./ca-i-2.png'),
};
