import React, { PureComponent } from 'react';
import { Text, View, TouchableWithoutFeedback, StyleSheet } from 'react-native';
import { ScaleAndOpacity } from 'react-native-motion';

import Header from './Header';
import Content from './Content';

class ListItem extends PureComponent {
  onPressed = event => {
    const { onPress, item } = this.props;
    onPress(item, event.nativeEvent);
  };
  render() {
    const { item, isSelected, style, isHidden, animateOnDidMount } = this.props;
    const { name, isReceived, ...rest } = item;

    return (
      <ScaleAndOpacity
        isHidden={isHidden}
        animateOnDidMount={animateOnDidMount}
      >
        <TouchableWithoutFeedback onPress={this.onPressed}>
          <View style={[styles.container, style]} pointerEvents="box-only">
            <Header name={name} isReceived={isReceived} />
            <Content {...rest} />
          </View>
        </TouchableWithoutFeedback>
      </ScaleAndOpacity>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginVertical: 4,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
  },
});

export default ListItem;
