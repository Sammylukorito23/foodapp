import React, { PureComponent } from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

class Avatar extends PureComponent {
  render() {
    const { text, src } = this.props;
    return (
      <View style={styles.container}>
        <Image style={styles.Imgcontainer} source={src} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },
  Imgcontainer:{
    justifyContent: 'center',
     flex: 1,
      resizeMode: 'contain',
  }
});

export default Avatar;
