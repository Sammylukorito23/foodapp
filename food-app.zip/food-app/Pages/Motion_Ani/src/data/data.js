import moment from 'moment';

const data = [
  {
    name: 'Ice Coffee',
    amount: '$1,500.67',
    date: moment(), 
    isReceived: false,
    items: [
      {
        name: 'Lather moto jacket',
        amount: '$8,564.00',
      },
      {
        name: 'Lorem ipsum',
        amount: '$358.00',
      },
      
    ],
  },
  {
    name: 'Burger Combo',
    amount: '$1,245.17',
    date: moment(),
    isReceived: true,
    items: [
      {
        name: 'Lather moto jacket',
        amount: '$8,564.00',
      },
      {
        name: 'Lorem ipsum',
        amount: '$358.00',
      },
      
    ],
  },
  {
    name: 'cappuccino',
    amount: '$545.28',
    date: moment(),
    isReceived: true,
    items: [
      {
        name: 'Lather moto jacket',
        amount: '$8,564.00',
      },
      {
        name: 'Lorem ipsum',
        amount: '$358.00',
      },
      
    ],
  },
  {
    name: 'veggie Meals',
    amount: '$375.37',
    date: moment(),
    isReceived: false,
    items: [
      {
        name: 'Lather moto jacket',
        amount: '$8,564.00',
      },
      {
        name: 'Lorem ipsum',
        amount: '$358.00',
      },
      
    ],
  },
  {
    name: 'Bread Omelette',
    amount: '$151.33',
    date: moment(),
    isReceived: true,
    items: [
      {
        name: 'Lather moto jacket',
        amount: '$8,564.00',
      },
      {
        name: 'Lorem ipsum',
        amount: '$358.00',
      },
      
    ],
  },
];

export default data;
