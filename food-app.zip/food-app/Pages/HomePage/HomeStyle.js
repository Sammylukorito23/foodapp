import { StyleSheet } from 'react-native';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
export default StyleSheet.create({
  homePageContainer: {
  	flex: 1,
    backgroundColor: '#fff', 
    paddingLeft: responsiveWidth(5),
    paddingRight: responsiveWidth(5), 
    // minHeight: '100%', 
  }, 
  HomePageTopSet: {
  	flex: 2,
    // backgroundColor: 'red', 
    // paddingBottom: 200, 
}, 
HomePageTopSetshap: {
  	position: 'relative',
  	flex: 1, 
          // resizeMode,
          width: '100%',
          justifyContent: 'center',
      right:  0,
      top:0,   
      left:0, 
      height: responsiveHeight(23), 
    transform: [  
      {skewY : '-16deg'},  
      {matrix: [ 
                2, 0, 0, 0,
                0, 2, 0, 0,
                0, 0, 1, 0,
                0, 0, 0, 1]},
    ],

    zIndex : 3,
}, 
HomePageLogo:{
  position: 'relative',
   // flex: 1,  
      bottom:0,  
      height: responsiveHeight(17), 
      width: responsiveWidth(30), 
      zIndex : 4,
      borderRadius: 100,
      marginTop:  responsiveHeight(2), 
},

HomePageBottomSet:{
	flex: 3, 
    // backgroundColor: '#ccc',
    paddingTop: responsiveHeight(3), 
},
TitleCenter:{
   alignItems: 'center',
  // flex: 1, 
 
}, 
HomePhoneInput: {
    // flex: 1, 
    borderWidth: 1,
    borderColor: '#000000',
    padding: responsiveHeight(2.1),
    marginTop: responsiveHeight(6),
    backgroundColor: '#fff', 
  }, 
  HomeFullWidthButtonContainer:{
    alignItems: 'center',
  },
  HomeFullWidthButton:{
    width: '100%', 
    backgroundColor: '#ff0000',
    height:responsiveHeight(6.7), 
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: responsiveHeight(3),
  },
  HomeFullWidthButtonText:{
    fontSize: responsiveFontSize(2),
    color: 'white',
  },
  HomeFotterTextContainer:{
    flex:1,   
    height: responsiveHeight(20),  
    flexDirection: 'row', 
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingBottom : responsiveHeight(3),
    zIndex : 5,
position: 'relative',
  }, 

  HomeFotterText:{
    // flex:1,   
    fontSize:responsiveFontSize(2),  
    color: '#8a8a8a',
    lineHeight:25,
  },

});