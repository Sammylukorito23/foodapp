import React , { Component } from 'react';
import { StyleSheet, Text, View, Image, KeyboardAvoidingView, TouchableHighlight, ScrollView, Button } from 'react-native';
import PhoneInput from 'react-native-phone-input';
import { createStackNavigator, } from 'react-navigation';
import { responsiveHeight, responsiveWidth, responsiveFontSize } from 'react-native-responsive-dimensions';
import style from './HomeStyle';
import DetailScreen from '../HotelsPage/HotelPage';



export default class HomeScreen extends React.Component {
    handleViewRef = ref => this.view = ref;
    bounceIn = () => this.view.bounceIn(800).then(endState => console.log(endState.finished ? 'bounceIn finished' : 'bounceIn cancelled'));
    static navigationOptions = {
        header: null,
    };
    constructor() {
        super();

        this.onPressFlag = this.onPressFlag.bind(this);
        this.selectCountry = this.selectCountry.bind(this);
        this.state = {
            cca2: 'us',
        };
    }

    

    onPressFlag() {
        this.countryPicker.openModal();
    }

    selectCountry(country) {
        this.phone.selectCountry(country.cca2.toLowerCase());
        this.setState({
            cca2: country.cca2
        });
    }


    render() {
        const {navigate} = this.props.navigation;
        return (
            <KeyboardAvoidingView style={{
                flex: 1,
                backgroundColor: '#fff',
            }} behavior="padding" enabled> 
      <ScrollView style={{
                flex: 1
            }}> 
      <View style={style.homePageContainer}>

        <View style={style.HomePageTopSet}>

         <Image style={style.HomePageTopSetshap} source={require('../../images/b-i-4.jpeg')} /> 
         <View style={{
                justifyContent: 'center',
                alignItems: 'center',
                flex: 1,
                flexDirection: 'row',
            }}> 
            <Image style={style.HomePageLogo} source={require('../../images/logo.png')} />
         </View> 

        </View> 

        <View style={style.HomePageBottomSet}>
        <View style={style.TitleCenter}> 
            <Text style={{
                fontSize: responsiveFontSize(3),
                color: '#000',
                fontWeight: 'bold',
                marginBottom: 5
            }}>Lets get started</Text> 
            <Text style={{
                fontSize: responsiveFontSize(1.7),
                color: '#000', 
            }}> Please enter your mobile number</Text>
        </View>
        <View style={style.HomePhoneInput}>   
           <PhoneInput textStyle={{ 
                fontSize: responsiveFontSize(1.7),
            }} initialCountry={'in'} ref={ref => {
                this.phone = ref;
            }} cca2={this.state.cca2}/>
        </View> 
        <View style={style.HomeFullWidthButtonContainer}  >
            <TouchableHighlight style={style.HomeFullWidthButton}  onPress={() => this.props.navigation.navigate('HotelScreen')}>  
            <Text style={style.HomeFullWidthButtonText}>{'Continue'.toUpperCase()}</Text>  
            </TouchableHighlight> 
        </View>
 
        <View style={style.HomeFotterTextContainer}>
          <Text style={style.HomeFotterText}>By creating an account you agree to our {"\n"} Terams of Service and Privacy Policy</Text>
        </View>

        </View>
      </View>  
     
      </ScrollView>  
      </KeyboardAvoidingView>
        );
    }
}


